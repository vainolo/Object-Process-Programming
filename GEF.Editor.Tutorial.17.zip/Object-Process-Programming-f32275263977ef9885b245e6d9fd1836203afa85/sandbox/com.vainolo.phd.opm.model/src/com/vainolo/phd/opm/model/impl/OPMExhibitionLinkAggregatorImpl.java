/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package com.vainolo.phd.opm.model.impl;

import com.vainolo.phd.opm.model.OPMExhibitionLinkAggregator;
import com.vainolo.phd.opm.model.OPMPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Exhibition Link Aggregator</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class OPMExhibitionLinkAggregatorImpl extends OPMStructuralLinkAggregatorImpl implements OPMExhibitionLinkAggregator {
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    protected OPMExhibitionLinkAggregatorImpl() {
        super();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    @Override
    protected EClass eStaticClass() {
        return OPMPackage.Literals.OPM_EXHIBITION_LINK_AGGREGATOR;
    }

} //OPMExhibitionLinkAggregatorImpl
