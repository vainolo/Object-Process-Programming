/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package com.vainolo.phd.opm.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Generalization Link Aggregator</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see com.vainolo.phd.opm.model.OPMPackage#getOPMGeneralizationLinkAggregator()
 * @model
 * @generated
 */
public interface OPMGeneralizationLinkAggregator extends OPMStructuralLinkAggregator {
} // OPMGeneralizationLinkAggregator
