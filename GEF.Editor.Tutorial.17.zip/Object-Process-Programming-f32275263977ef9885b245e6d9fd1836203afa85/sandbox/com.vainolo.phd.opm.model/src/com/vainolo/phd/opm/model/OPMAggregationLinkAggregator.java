/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package com.vainolo.phd.opm.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Aggregation Link Aggregator</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see com.vainolo.phd.opm.model.OPMPackage#getOPMAggregationLinkAggregator()
 * @model
 * @generated
 */
public interface OPMAggregationLinkAggregator extends OPMStructuralLinkAggregator {
} // OPMAggregationLinkAggregator
