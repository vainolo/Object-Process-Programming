/**
 * EditParts used in the OPM GEF editor.
 */
package com.vainolo.phd.opm.gef.editor.part;

