package com.vainolo.phd.opm.gef.editor.figure;

import org.eclipse.draw2d.Label;

public interface NamedNodeFigure extends NodeFigure {
	public Label getNameLabel();	
}
