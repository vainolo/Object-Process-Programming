/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package com.vainolo.phd.opm.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Exhibition Link Aggregator</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see com.vainolo.phd.opm.model.OPMPackage#getOPMExhibitionLinkAggregator()
 * @model
 * @generated
 */
public interface OPMExhibitionLinkAggregator extends OPMStructuralLinkAggregator {
} // OPMExhibitionLinkAggregator
