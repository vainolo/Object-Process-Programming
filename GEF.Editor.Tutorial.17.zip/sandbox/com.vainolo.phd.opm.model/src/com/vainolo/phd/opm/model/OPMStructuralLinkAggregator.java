/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package com.vainolo.phd.opm.model;

import org.eclipse.draw2d.geometry.Point;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Structural Link Aggregator</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see com.vainolo.phd.opm.model.OPMPackage#getOPMStructuralLinkAggregator()
 * @model
 * @generated
 */
public interface OPMStructuralLinkAggregator extends Node {

} // OPMStructuralLinkAggregator
