/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package com.vainolo.phd.opm.model.impl;

import com.vainolo.phd.opm.model.OPMGeneralizationLinkAggregator;
import com.vainolo.phd.opm.model.OPMPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Generalization Link Aggregator</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class OPMGeneralizationLinkAggregatorImpl extends OPMStructuralLinkAggregatorImpl implements OPMGeneralizationLinkAggregator {
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    protected OPMGeneralizationLinkAggregatorImpl() {
        super();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    @Override
    protected EClass eStaticClass() {
        return OPMPackage.Literals.OPM_GENERALIZATION_LINK_AGGREGATOR;
    }

} //OPMGeneralizationLinkAggregatorImpl
