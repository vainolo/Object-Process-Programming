package tests.part;

import org.eclipse.gef.editparts.AbstractConnectionEditPart;

public class LinkEditPart extends AbstractConnectionEditPart {

	
	
	@Override
	protected void createEditPolicies() {
		// TODO Auto-generated method stub

	}

}
